## Configuration management: Default folder

All site configuration will be tracked in this folder. These files should be commited to the repository and will be imported on deploy automatically.
